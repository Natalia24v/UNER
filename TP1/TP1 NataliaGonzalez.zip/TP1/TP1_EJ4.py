numero1 = float(input("Ingrese el primer numero: "))
numero2 = float(input("Ingrese el segundo numero: "))
suma = numero1 + numero2
print("La respuesta es: " + str(suma))