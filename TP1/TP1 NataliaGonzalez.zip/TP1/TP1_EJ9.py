#9. Pida al usuario que ingrese un texto para luego imprimirlo al revés. Ej: HOLA -> ALOH.

txt = input("Ingrese una palabra: ")

# Se usa el operador de slicing para invertir el string o cadena de texto
print(txt[::-1])