#8. Escriba un programa que permita al usuario ingresar la base y altura de un triángulo para
# luego imprimir por pantalla la superficie total.

base = float(input("Ingrese la base del triangulo: "))
altura = float(input("Ingrese la altura del triangulo: "))

resultado = (base * altura) / 2

print("La superficie del triangulo es: ", resultado)