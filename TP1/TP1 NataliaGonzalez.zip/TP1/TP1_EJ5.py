numero1 = float(input("Ingrese el primer numero: "))
numero2 = float(input("Ingrese el segundo numero: "))
numero3 = float(input("ingrese el tercer numero: "))
suma = numero1 + numero2
multip = suma * numero3
print("La respuesta es: " + str(multip))