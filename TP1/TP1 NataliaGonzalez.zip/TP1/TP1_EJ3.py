nombre = input("Bienvenido, por favor ingrese su nombre: ")
apellido = input("Ahora por favor ingrese su apellido: ")
print("Hola " + nombre + " " + apellido)