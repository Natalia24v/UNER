nombre = input("Bienvenido, por favor ingrese su nombre: ")
print("Hola " + nombre)