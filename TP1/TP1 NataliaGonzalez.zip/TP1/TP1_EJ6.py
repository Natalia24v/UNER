costo_total = float(input("Ingrese la cantidad total de la cuenta: $"))
comensales = float(input("Ingrese el numero de comensales: "))

resultado = costo_total / comensales

print("Cada persona debe abonar: $" + str(resultado))